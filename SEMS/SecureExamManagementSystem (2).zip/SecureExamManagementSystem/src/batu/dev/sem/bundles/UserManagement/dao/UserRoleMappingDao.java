package batu.dev.sem.bundles.UserManagement.dao;

public interface UserRoleMappingDao {

}
