package batu.dev.sem.bundles.UserManagement.dao;

import java.util.List;

import batu.dev.sem.bundles.UserManagement.entity.RoleEntity;

public interface RolesDao {

	List<RoleEntity> getAll();

}
