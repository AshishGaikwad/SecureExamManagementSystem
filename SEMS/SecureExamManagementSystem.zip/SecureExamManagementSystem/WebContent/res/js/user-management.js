$(document).ready(function(){
	createScreen();
});



$(window).load(function(){
	createScreen();
});





function createScreen()
{
	$("body#create_screen").load(function(){
		alert("Hiee");
	});

}