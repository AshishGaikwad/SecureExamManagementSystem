package batu.dev.sem.bundles.UserManagement.dao;

public interface RoleScreenMappingDao {

}
