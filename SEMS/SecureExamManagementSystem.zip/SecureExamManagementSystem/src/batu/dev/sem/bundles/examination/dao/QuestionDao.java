package batu.dev.sem.bundles.examination.dao;

import java.util.List;

import batu.dev.sem.bundles.examination.entity.QuestionEntity;

public interface QuestionDao 
{
	public String create(QuestionEntity pQuestionEntity);
	public String update(QuestionEntity pQuestionEntity);
	public String delete(long pQuestionId);
	public List<QuestionEntity> get();
	public List<QuestionEntity> get(long pQuestionId);
	public List<QuestionEntity> get(String pQuestion);
	public List<QuestionEntity> getBySubject(long pSubjectId);
	public String getSubjectQuestionDetails(long pSubjectId);
	
	
	
	
}
