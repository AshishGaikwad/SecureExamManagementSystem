package batu.dev.sem.bundles.examination.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.google.gson.Gson;

import batu.dev.sem.bundles.examination.dao.ExaminationDao;
import batu.dev.sem.bundles.examination.daoimpl.ExaminationDaoImpl;
import batu.dev.sem.bundles.examination.entity.ExaminationEntity;
import batu.dev.sem.utils.Util;

/**
 * Servlet implementation class ExaminationController
 */
@WebServlet("/ExaminationController")
public class ExaminationController extends HttpServlet {
	private Gson gson = new Gson();
	ExaminationDao lExaminationDao = new ExaminationDaoImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String FormType = request.getParameter("FormType");

		switch (FormType) {
		case "SaveExamination":
			save(request, response);
			break;
		case "UpdateExamination":
			update(request, response);
			break;
		case "GetExaminationListBySubject":
			getExaminationListBySubject(request, response);
			break;
		case "GetExaminationData":
			getExaminationData(request, response);
			break;
		case "GetExaminations":
			getExaminations(request, response);
			break;

		case "ExaminationsDetailsTable":
			examinationsDetailsTable(request, response);
			break;

		default:
			break;
		}
	}

	private void examinationsDetailsTable(HttpServletRequest request, HttpServletResponse response) {
		try {
			ExaminationEntity lExaminationEntity = lExaminationDao.get(Long.parseLong(request.getParameter("ExaminationId").trim()));
			
			
			StringBuilder lBuilder = new StringBuilder().append("<table class=\"table table-bordered mb-none\">").append("<tbody>");
			lBuilder.append("<tr><td>Examination Id</td>").append("<td>").append(lExaminationEntity.geteId()).append("</td></tr>");
			lBuilder.append("<tr><td>Examination Title</td>").append("<td>").append(lExaminationEntity.geteTitle()).append("</td></tr>");
			lBuilder.append("<tr><td>Total Questions </td>").append("<td>").append(lExaminationEntity.geteTotalQue()).append("</td></tr>");
			lBuilder.append("<tr><td>Total Marks </td>").append("<td>").append(lExaminationEntity.geteTotalMarks()).append("</td></tr>");
			lBuilder.append("<tr><td>Passing Marks </td>").append("<td>").append(lExaminationEntity.getePassingMarks()).append("</td></tr>");
			lBuilder.append("<tr><td>Examination Duration </td>").append("<td>").append(lExaminationEntity.geteDuration()).append("</td></tr>");
			lBuilder.append("<tr><td>Examination Description</td>").append("<td>").append(lExaminationEntity.geteDescription()).append("</td></tr>");
			lBuilder.append("<tr><td>Admission Start Date </td>").append("<td>").append(lExaminationEntity.geteAdmissionStartDate()).append("</td></tr>");
			lBuilder.append("<tr><td>Admission Start Date </td>").append("<td>").append(lExaminationEntity.geteAdmissionLastDate()).append("</td></tr>");
			lBuilder.append("<tr><td>Hall Ticket  Date </td>").append("<td>").append(lExaminationEntity.geteHallTicketDate()).append("</td></tr>");
			lBuilder.append("<tr><td>Examination Date </td>").append("<td>").append(lExaminationEntity.geteDate()).append("</td></tr>");
			lBuilder.append("<tr><td>Result Date </td>").append("<td>").append(lExaminationEntity.geteResultDate()).append("</td></tr>");
			lBuilder.append("<tr><td>Examination Fee</td>").append("<td>").append(lExaminationEntity.geteFee()).append("</td></tr>");
			lBuilder.append("</tbody>").append("</table>");
			
				
			response.getWriter().print(lBuilder.toString());
			
		
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}

	private void getExaminations(HttpServletRequest request, HttpServletResponse response) {
		try {
			response.getWriter().print(gson.toJson(lExaminationDao.get()));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void update(HttpServletRequest request, HttpServletResponse response) {
		try {
			JSONObject body = new JSONObject(request.getParameter("Body"));

			ExaminationEntity lExaminationEntity = new ExaminationEntity();
			lExaminationEntity.seteId(Long.parseLong(request.getParameter("ExaminationId")));
			lExaminationEntity.seteTitle(body.getString("eTitle"));
			lExaminationEntity.seteSubjectId(body.getLong("SubjectList"));
			lExaminationEntity.seteTotalQue(body.getLong("TotalQuestions"));
			lExaminationEntity.seteMarkQueDetails(body.getString("MarkQueDetails"));
			lExaminationEntity.seteTotalMarks(body.getLong("TotalMarks"));
			lExaminationEntity.setePassingMarks(body.getLong("PassingMarks"));
			lExaminationEntity.seteDuration(body.getLong("ExamDuration"));
			lExaminationEntity.seteDescription(body.getString("Description"));
			lExaminationEntity.seteAdmissionStartDate(body.getString("AdmissionStartDate"));
			lExaminationEntity.seteAdmissionLastDate(body.getString("AdmissionEndDate"));
			lExaminationEntity.seteHallTicketDate(body.getString("HallTicketDate"));
			lExaminationEntity.seteDate(body.getString("ExaminationDate"));
			lExaminationEntity.seteResultDate(body.getString("ResultDate"));
			lExaminationEntity.seteDate(body.getString("ExaminationDate"));
			lExaminationEntity.seteFee(body.getDouble("ExaminationFee"));
			lExaminationEntity.seteIsActive(body.getInt("IsActive"));
			response.getWriter().print(lExaminationDao.update(lExaminationEntity));
		} catch (Exception e) {
			e.printStackTrace();
			try {
				response.getWriter().print(Util.nofity("Something went wrong please try again.", "error"));
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

	}

	private void getExaminationData(HttpServletRequest request, HttpServletResponse response) {
		try {
			response.getWriter().print(
					gson.toJson(lExaminationDao.get(Long.parseLong(request.getParameter("ExaminationId").trim()))));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	private void getExaminationListBySubject(HttpServletRequest request, HttpServletResponse response) {
		try {
			response.getWriter().print(
					gson.toJson(lExaminationDao.getOnSubjectId(Long.parseLong(request.getParameter("SubjectId")))));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void save(HttpServletRequest request, HttpServletResponse response) {
		try {
			JSONObject body = new JSONObject(request.getParameter("Body"));

			ExaminationEntity lExaminationEntity = new ExaminationEntity();
			lExaminationEntity.seteTitle(body.getString("eTitle"));
			lExaminationEntity.seteSubjectId(body.getLong("SubjectList"));
			lExaminationEntity.seteTotalQue(body.getLong("TotalQuestions"));
			lExaminationEntity.seteMarkQueDetails(body.getString("MarkQueDetails"));
			lExaminationEntity.seteTotalMarks(body.getLong("TotalMarks"));
			lExaminationEntity.setePassingMarks(body.getLong("PassingMarks"));
			lExaminationEntity.seteDuration(body.getLong("ExamDuration"));
			lExaminationEntity.seteDescription(body.getString("Description"));
			lExaminationEntity.seteAdmissionStartDate(body.getString("AdmissionStartDate"));
			lExaminationEntity.seteAdmissionLastDate(body.getString("AdmissionEndDate"));
			lExaminationEntity.seteHallTicketDate(body.getString("HallTicketDate"));
			lExaminationEntity.seteDate(body.getString("ExaminationDate"));
			lExaminationEntity.seteResultDate(body.getString("ResultDate"));
			lExaminationEntity.seteDate(body.getString("ExaminationDate"));
			lExaminationEntity.seteFee(body.getDouble("ExaminationFee"));
			lExaminationEntity.seteIsActive(body.getInt("IsActive"));
			response.getWriter().print(lExaminationDao.create(lExaminationEntity));
		} catch (Exception e) {
			e.printStackTrace();
			try {
				response.getWriter().print(Util.nofity("Something went wrong please try again.", "error"));
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

	}

}
